# core/guest_id.py

def get_guest_id():
    # For now, return a constant guest_id. Replace with real logic as needed.
    return "guest_whatsapp_025"